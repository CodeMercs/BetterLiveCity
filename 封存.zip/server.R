library(shiny)
require(ggplot2)


theFiles <- dir("data//WRDataUTF8", pattern = "\\.csv")
explot <- list()
for (n in c(1:length(theFiles))) {
  explot[[theFiles[n]]] <-
    read.csv(paste0("data//WRDataUTF8//", theFiles[n]))
}
ophren<-list()

for ( area in c(1:length(explot[[theFiles[109]]][,1]))) {
  explot<-list()
  type  <-c()
  warm  <-c()
  y     <-c()
  for(n in c(1:length(theFiles))){
    explot[[theFiles[n]]]<-read.csv(paste0("data//WRDataUTF8//", theFiles[n]), stringsAsFactors = FALSE )
    ifelse(is.null(explot[[theFiles[n]]][area,2]),type[n] <-c(0),type[n] <-c(explot[[theFiles[n]]][area,2]))
    ifelse(is.null(explot[[theFiles[n]]][area,8]),warm[n] <-c(0),warm[n] <-c(explot[[theFiles[n]]][area,8]))
    ifelse(is.null(substring(theFiles[n],4,9)),y[n] <-c(0),y[n] <-substring(theFiles[n],4,9))
  }
  st<- explot[[theFiles[109]]][,1][area]
  ophren[[st]] <- data.frame(
    TIME = y, 
    TAVE = type,
    CHA  = warm
  )
  
}


shinyServer(function(input, output, session){
  
  # When we change from one `tabPanel` to another, update the URL hash 
  observeEvent(input$tabs, { 
    # No work to be done if input$tabs and the hash are already the same 
    if (getUrlHash() == input$tabs) return() 
    
    # The 'push' argument is necessary so that the hash change event occurs and 
    # so that the other observer is triggered. 
    updateQueryString(
      paste0(getQueryString(), input$tabs), 
      "push" 
    ) 
    # Don't run the first time so as to not generate a circular dependency 
    # between the two observers 
  }, ignoreInit = TRUE) 
  
  # When the hash changes (due to clicking on the link in the sidebar or switching 
  # between the `tabPanel`s), switch tabs and update an input. Note that clicking 
  # another `tabPanel` already switches tabs. 
  observeEvent(getUrlHash(), { 
    hash <- getUrlHash() 
    
    # No work to be done if input$tabs and the hash are already the same 
    if (hash == input$tabs) return() 
    
    valid <- c("#panel1", "#panel2", "#panel3", "#panel4", "#panel5", "#panel6", "#panel7") 
    
    if (hash %in% valid) { 
      updateTabsetPanel(session, "tabs", hash) 
    } 
  })


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#  
  
#  output$exPlot<-renderPlot({
#    ggplot(dt, aes(x = dt$AREA, y = dt$TAVE)) + geom_bar(stat ="identity")
#  })
#  output$exPlot2<-renderPlot({
#    ggplot(ot, aes(x = ot$AREA, y = ot$TAVE)) + geom_bar(stat ="identity")
#  })
#  output$exPlot3<-renderPlot({
#    ggplot(ft, aes(x = ft$AREA, y = ft$TAVE)) + geom_bar(stat ="identity")
#  })
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#  
  output$exPlot<-renderPlot({
    ggplot(ophren[[input$select]], aes(x = ophren[[input$select]]$TIME, y = ophren[[input$select]]$TAVE)) + geom_bar(stat ="identity",width=0.5, fill = "#33CCFF")+geom_text(mapping = aes(label= ophren[[input$select]]$TAVE),color ="orange",vjust = -0.5, size = 5)+geom_line()+theme(axis.title.y = element_text(angle = 0, family = "宋體-繁 細體"),
                                                                                                                                                                                                                                                                                         axis.text.x = element_text(angle = 60, family = "宋體-繁 細體", hjust = 1),
                                                                                                                                                                                                                                                                                         axis.title.x = element_text(family = "宋體-繁 細體"))
  })
  output$exPlot2<-renderPlot({
    ggplot(ophren[[input$select2]], aes(x = ophren[[input$select2]]$TIME, y = ophren[[input$select2]]$CHA)) + geom_bar(stat ="identity",width=0.5, fill = "#FF0000")+geom_text(mapping = aes(label= ophren[[input$select2]]$CHA),color ="orange",vjust = -0.5, size = 5)+geom_line()+theme(axis.title.y = element_text(angle = 0, family = "宋體-繁 細體"),
                                                                                                                                                                                                                                                                                           axis.text.x = element_text(angle = 60, family = "宋體-繁 細體", hjust = 1),
                                                                                                                                                                                                                                                                                           axis.title.x = element_text(family = "宋體-繁 細體"))
  })
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
  

    })