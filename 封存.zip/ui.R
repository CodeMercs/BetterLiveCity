
theFiles <- dir("data//WRDataUTF8", pattern = "\\.csv")
explot<-list()
for (n in c(1:length(theFiles))) {
  explot[[theFiles[n]]] <-read.csv(paste0("data//WRDataUTF8//", theFiles[n]))
}
shinyUI(
  fluidPage(
    HTML("<head>
		        <title>宜居城市</title>
            <meta charset=\"utf-8\" />
            <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
            <link rel=\"stylesheet\" href=\"assets/css/main.css\" />
          </head>"),
    
    HTML("<!-- Header -->
		    	  <header id=\"header\">
              <div class=\"inner\">
                <a href=\"index.html\" class=\"logo\"><strong>宜居城市</strong></a>
                <nav id=\"nav\">
                  <a href=\"#panel1\">程式介紹</a>
                  <a href=\"#panel2\">氣候狀況</a>
                  <a href=\"#panel3\">環境狀況</a>
                  <a href=\"#panel4\">公共運輸</a>
                  <a href=\"#panel5\">進修單位</a>
                  <a href=\"#panel6\">休閒娛樂</a>
                  <a href=\"index.html\">醫院設施</a>
                </nav>
                <a href=\"#navPanel\" class=\"navPanelToggle\"><span class=\"fa fa-bars\"></span></a>
              </div>
           </header>
           
          <!-- Banner -->
            <section id=\"banner\">
              <div class=\"inner\">
                <header>
                  <h1><strong><font color=\"white\">宜居城市</font></strong></h1>
                </header>
           
                <footer>
                    <a href=\"#\" class=\"button\">了解詳情</a>
                </footer>
              </div>
            </section>"),
    
    HTML("<!-- Scripts -->
			      <script src=\"assets/js/jquery.min.js\"></script>
            <script src=\"assets/js/skel.min.js\"></script>
            <script src=\"assets/js/util.js\"></script>
            <script src=\"assets/js/main.js\"></script>"),
 
    tabsetPanel(id = "tabs",
      tabPanel("123",
        fluidPage(
          sidebarLayout(
            sidebarPanel(h3(tags$b("宜居城市"))
                        , h4("　　高齡人口適合居住之地區")
                        , h6("Souce：", tags$a(href="https://data.gov.tw", "政府資料開放平台"))),
            mainPanel())), value = "#panel1"),
      tabPanel("平均溫度",
               fluidPage(
                 sidebarLayout(
                   sidebarPanel(selectInput("select", "Temperature:", choices=explot[[theFiles[109]]][,1]),
                                hr(),
                                helpText("Standard temperature Celsius 20 degree,Fahrenheit 68 degree")),
                   mainPanel(plotOutput("exPlot")))), value = "#panel2"),
             
      tabPanel("平均溼度",
               fluidPage(
                 sidebarLayout( 
                   sidebarPanel(selectInput("select2", "Humidity:", choices=explot[[theFiles[109]]][,1]),
                                hr(),
                                helpText("Data from AT&T (1961) The World's Telephones.")),
                   mainPanel(plotOutput("exPlot2"))),HTML("<head>
		        <title>宜居城市</title>
                                                          <meta charset=\"utf-8\" />
                                                          <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
                                                          <link rel=\"stylesheet\" href=\"assets/css/main.css\" />
                                                          </head>"),
                 
                 HTML("<!-- Header -->
                      <header id=\"header\">
                      <div class=\"inner\">
                      <a href=\"index.html\" class=\"logo\"><strong>宜居城市</strong></a>
                      <nav id=\"nav\">
                      <a href=\"#panel1\">程式介紹</a>
                      <a href=\"#panel2\">氣候狀況</a>
                      <a href=\"#panel3\">環境狀況</a>
                      <a href=\"#panel4\">公共運輸</a>
                      <a href=\"#panel5\">進修單位</a>
                      <a href=\"#panel6\">休閒娛樂</a>
                      <a href=\"index.html\">醫院設施</a>
                      </nav>
                      <a href=\"#navPanel\" class=\"navPanelToggle\"><span class=\"fa fa-bars\"></span></a>
                      </div>
                      </header>
                      
                      <!-- Banner -->
                      <section id=\"banner\">
                      <div class=\"inner\">
                      <header>
                      <h1><strong><font color=\"white\">宜居城市</font></strong></h1>
                      </header>
                      
                      <footer>
                      <a href=\"#\" class=\"button\">了解詳情</a>
                      </footer>
                      </div>
                      </section>")), value = "#panel3"),
             
      tabPanel("", value = "#panel5"),
             
      tabPanel("", value = "#panel6"),
             
      tabPanel("", value = "#panel7"))
    ))